<?php
phpinfo()