<form method="post" action="{{ route('contact') }}">
    {{ csrf_field() }}