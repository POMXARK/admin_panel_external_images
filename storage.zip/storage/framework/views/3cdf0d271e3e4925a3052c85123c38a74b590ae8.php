<?php echo $__env->make('additions', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 


<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Document</title>




</head>
<body>
  

<?php echo $__env->make('header_main_menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
		<div class="hover14 column">
  	<?php $__currentLoopData = $photo_pagination; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $url_photo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    
    		<a data-fancybox="gallery" href="<?php echo e($url_photo->photo_link); ?>"><div class='filters__img '><figure><img src="<?php echo e($url_photo->mini_photo_link); ?>" '></figure></div></a>


		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</div>
  </tbody>
  
</table>
<?php echo e($photo_pagination->links()); ?> 

</body>
</html><?php /**PATH N:\OSPanel\domains\App\resources\views/photo_pagination.blade.php ENDPATH**/ ?>