<?php echo $__env->make('additions', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 

<?php echo $__env->make('header_main_menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php echo Form::open(['action' => 'BDInsertController@BD_insert']); ?>

<?php echo Form::label('name', 'Ссылки на фото imbb - Коды для встраивания - HTML - код полноразмерного со ссылкой https://imgbb.com/ :' , ['class' => 'form-control container ']); ?>

  <?php echo Form::textarea('html_arr', null, ['class' => 'form-control container ']); ?>

  <br>
  <?php echo Form::submit('Загрузить фото ' , ['class' => 'form-control container  btn-primary'] ); ?>

  <?php echo Form::close(); ?>




<!-- <form method="POST" action="content\foto">
<div class="form-group">
    <label for="exampleFormControlInput1">Email address</label>
    <input type="email" class="form-control" id="exampleFormControlInput1" placeholder="name@example.com">
  </div>
  <div class="form-group">
    <label for="exampleFormControlSelect1">Example select</label>
    <select class="form-control" id="exampleFormControlSelect1">
      <option>1</option>
      <option>2</option>
      <option>3</option>
      <option>4</option>
      <option>5</option>
    </select>
  </div>
  <div class="form-group">
    <label for="exampleFormControlSelect2">Example multiple select</label>
    <select multiple class="form-control" id="exampleFormControlSelect2">
      <option>1</option>
      <option>2</option>
      <option>3</option>
      <option>4</option>
      <option>5</option>
    </select>
  </div>
  <div class="form-group container">
    <label for="exampleFormControlTextarea1">Ссылки на фото</label>
    <textarea class="form-control" id="exampleFormControlTextarea1" rows="9"></textarea>
    <br>
    <button type="submit" class="btn btn-primary">Загрузить</button>

  </div>

</form>
<td><button onclick="location.href='<?php echo e(url('\welcome')); ?>'">
     Check Stock</button></td> --><?php /**PATH N:\OSPanel\domains\App\resources\views/admin\input_form.blade.php ENDPATH**/ ?>