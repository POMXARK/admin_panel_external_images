<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Document</title>
</head>
<body>
	<ul>
		<?php $__currentLoopData = $url_photo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $photo_link): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<li>
				<a href="<?php echo e($photo_link-> photo_link); ?>">
				<?php echo e($photo_link-> photo_link); ?>

				</a>
			</li>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
	</ul>
</body>
</html><?php /**PATH N:\OSPanel\domains\App\resources\views/tasks/view_bd.blade.php ENDPATH**/ ?>