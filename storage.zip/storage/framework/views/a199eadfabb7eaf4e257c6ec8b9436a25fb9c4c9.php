<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Document</title>
</head>
<body>

	<?php echo Form::open(['action' => 'UserController@index']); ?>

	<?php echo Form::label('name', 'Name:'); ?>

	<?php echo Form::textarea('html_arr', null, ['class' => 'form-control']); ?>

	<?php echo Form::submit('Загрузить' , ['class' => 'form-control'] ); ?>

	<?php echo Form::close(); ?>


	<?php 

		//echo Form::open(['url' => 'content\foto', 'method' => 'post']);

		//echo link_to_action('UserController@index', $title = null, $parameters = [], $attributes = []);
		//echo link_to('web', $title = null, $attributes = [], $secure = null);
		//echo Form::textarea('keterangan', null, ['id' => 'keterangan', 'rows' => 4, 'cols' => 54, 'style' => 'resize:none']);
		//echo "<br>";
		//echo Form::submit('Click Me!');
	?>

</body>
</html>


<?php /**PATH N:\OSPanel\domains\App\resources\views/hello.blade.php ENDPATH**/ ?>