<?php
phpinfo() ?><?php /**PATH N:\OSPanel\domains\App\resources\views/test_php.blade.php ENDPATH**/ ?>