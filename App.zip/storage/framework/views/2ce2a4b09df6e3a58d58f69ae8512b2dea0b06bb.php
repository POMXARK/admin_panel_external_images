<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Document</title>
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">

</head>
<body>
<div class="container">
	<table class="table table-dark">
  <thead>
    <tr>
    	<th scope="col">Id</th>
      <th scope="col">Name</th>    	
      <th scope="col">Mail</th>
    </tr>
  </thead>
  
  <tbody>
  	<?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
    		
    		<!--<td><?php echo e($loop->index +1); ?></td>-->
    		<td><?php echo e($user->id); ?></td>
				<td><?php echo e($user->name); ?></td>
				<td><?php echo e($user->email); ?></td>

    </tr>
    <tr>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </tbody>
  
</table>
<?php echo e($users->links()); ?>

</div>
</body>
</html><?php /**PATH N:\OSPanel\domains\App\resources\views/Pagination.blade.php ENDPATH**/ ?>