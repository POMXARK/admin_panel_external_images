<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">

<form method="POST" action="<?php echo e(route('web')); ?>">
<!--  <div class="form-group">
    <label for="exampleFormControlInput1">Email address</label>
    <input type="email" class="form-control" id="exampleFormControlInput1" placeholder="name@example.com">
  </div>
  <div class="form-group">
    <label for="exampleFormControlSelect1">Example select</label>
    <select class="form-control" id="exampleFormControlSelect1">
      <option>1</option>
      <option>2</option>
      <option>3</option>
      <option>4</option>
      <option>5</option>
    </select>
  </div>
  <div class="form-group">
    <label for="exampleFormControlSelect2">Example multiple select</label>
    <select multiple class="form-control" id="exampleFormControlSelect2">
      <option>1</option>
      <option>2</option>
      <option>3</option>
      <option>4</option>
      <option>5</option>
    </select>
  </div>-->
  <div class="form-group container">
    <label for="exampleFormControlTextarea1">Ссылки на фото</label>
    <textarea class="form-control" id="exampleFormControlTextarea1" rows="9"></textarea>
    <br>
    <button type="submit" class="btn btn-primary">Загрузить</button>
  </div>

</form><?php /**PATH N:\OSPanel\domains\App\resources\views/admin/input_form.blade.php ENDPATH**/ ?>