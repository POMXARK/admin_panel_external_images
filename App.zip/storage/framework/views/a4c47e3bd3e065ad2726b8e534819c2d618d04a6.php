<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Document</title>
</head>
<body>
	<h1> <?php echo e($task -> body); ?> </h1>
</body>
</html><?php /**PATH N:\OSPanel\domains\App\resources\views/tasks/show.blade.php ENDPATH**/ ?>