<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class create_url_photo_table extends Model
{
    //
}
